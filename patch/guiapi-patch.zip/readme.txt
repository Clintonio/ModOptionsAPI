Put the .class file into your minecraft.jar
